<footer id="footer">
		<div class="container">
			<div class="list-service-footer">
				<ul class="list-none">
					<li><a href="#"><img src="images/home/jewelry2/icon1.png" alt="" /></a> <span class="desc dark opaci">REMOTE CONSULTATION</span></li>
					<li><a href="#"><img src="images/home/jewelry2/icon2.png" alt="" /></a> <span class="desc dark opaci">FREE AFTER CARE</span></li>
					<li><a href="#"><img src="images/home/jewelry2/icon3.png" alt="" /></a> <span class="desc dark opaci">TESTED & CERTIFIED DIAMONDS</span></li>
					<li><a href="#"><img src="images/home/jewelry2/icon5.jpg" alt="" /></a> <span class="desc dark opaci">HALLMARK JWELLERY</span></li>
					<li><a href="#"><img src="images/home/jewelry2/icon4.png" alt="" /></a> <span class="desc dark opaci">GUARANTEED PAYBACK</span></li>
				</ul>
			</div>
		</div>
		<footer id="footer">
		<div class="footer2 bg-dark">
			<div class="container">
				<div class="main-footer2">
					<div class="row">
						<div class="col-md-4 col-sm-4 col-xs-12">
							<div class="block-footer2">
								<h2 class="title18 play-font white text-uppercase font-bold">newsletter</h2>
								<p class="desc white opaci">Sign up to our newsletter to receive updates on the art of Coin.</p>
								<form class="form-newsletter2 dark-style">
									<input type="text" placeholder="EMAIL ADDRESS">
									<input type="submit" value="Subscription">
								</form>
							</div>
						</div>
						<div class="col-md-4 col-sm-4 col-xs-12">
							<div class="block-footer2">
								<div class="logo logo-footer2 text-center">
									<a href="index-2.html">
									
										<strong class="play-font font-normal title30 white text-uppercase">SR</strong>
										<span class="play-font font-normal title30 white">Jwellers</span>
									</a>
								</div>
								<h2 class="title18 play-font  white text-center text-uppercase font-bold">FOLLOW US ON</h2>
								<div class="social-network-footer text-center">
									<a href="#" class="inline-block round"><i class="fa fa-facebook"></i></a>
									<a href="#" class="inline-block round"><i class="fa fa-twitter"></i></a>
									<a href="#" class="inline-block round"><i class="fa fa-pinterest-p"></i></a>
								</div>
							</div>
						</div>
						<div class="col-md-4 col-sm-4 col-xs-12">
							<div class="block-footer2">
								<h2 class="title18 play-font white text-uppercase font-bold">Contact Us</h2>
								<p class="desc white opaci">Don't hesitate in contacting us for any questions you might have.</p>
								<ul class="list-none contact-foter2">
									<li>
										<i class="fa fa-location-arrow white"></i>
										<span class="text-uppercase white opaci">Sadar Bajar, Gurgaon, Haryana 122001</span>
									</li>
								
									<li>
										<i class="fa fa-volume-control-phone white"></i>
										<span class="text-uppercase white opaci">+91-9811369903 <br>  0124-233257</span>
									</li>
									<li>
										<i class="fa fa-location-arrow white"></i>
										<span class="text-uppercase white opaci">Near Gurudwara Road Showroom, Gurgaon, Haryana 122001</span>
									</li>
								
									<li>
										<i class="fa fa-volume-control-phone white"></i>
										<span class="text-uppercase white opaci">+91-9773556210;+91-9910590048 <br>  +91-124-4066570;+91-124-4077570</span>
									</li>
									<li>
										<i class="fa fa-envelope white"></i>
										<a class="white opaci" href="mailto:demo@example.com">shriram@shriramjwellwers.in</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<!-- End Main Footer -->
				<div class="footer-bottom2">
					<ul class="footer-menu text-uppercase text-center list-inline-block">
						<li><a href="contact.html" class="white opaci">CONTACT US</a></li>
						<li><a href="#" class="white opaci">SITEMAP</a></li>
						<li><a href="#" class="white opaci">TERMS & CONDITIONS</a></li>
						<li><a href="#" class="white opaci">RETURN POLICY</a></li>
						<li><h2 class="title18 play-font white text-uppercase font-bold">GIFT CARDS</h2></li>
						<li><a href="#" class="white opaci">Privacy &amp; Cookies</a></li>
						<li><a href="about.html" class="white opaci">About Us</a></li>
					</ul>
				</div>
			</div>
		</div>
	</footer>
	<!-- End Footer -->
	<div class="wishlist-mask">
		<div class="wishlist-popup">
			<span class="popup-icon"><i class="fa fa-bullhorn" aria-hidden="true"></i></span>
			<p class="wishlist-alert">"SRJ Product" was added to wishlist</p>
			<div class="wishlist-button">
				<a href="#">Continue Shopping (<span class="wishlist-countdown">5</span>)</a>
				<a href="#">Go To Shopping Cart</a>
			</div>
		</div>
	</div>
	<!-- End Wishlist Mask -->
	<div id="loading">
		<div id="loading-center">
			<div id="loading-center-absolute">
				
				<div class="object" id="object_two"></div>
			</div>
		</div>
	</div>
	<!-- End Preload -->
	<div>
	<a href="#" class="scroll-top dark"><i class="fa fa-angle-up"></i></a>
</div>
<script src="js/libs/jquery-3.2.1.min.js"></script>
<script src="js/libs/bootstrap.min.js"></script>
<script src="js/libs/jquery.fancybox.min.js"></script>
<script src="js/libs/jquery-ui.min.js"></script>
<script src="js/libs/owl.carousel.min.js"></script>
<script src="js/libs/jquery.jcarousellite.min.js"></script>
<script src="js/libs/jquery.mCustomScrollbar.min.js"></script>
<script src="js/libs/jquery.elevatezoom.min.js"></script>
<script src="js/libs/popup.min.js"></script>
<script src="js/libs/timecircles.min.js"></script>
<script src="js/libs/wow.min.js"></script>
<script src="js/theme.js"></script>