
jQuery(document).ready(function () { 
    
    /*====Modal=====*/
    setTimeout(function() {
        jQuery('#enquiry_modal').modal();
    }, 9000);

    /*===Mega-Menu-On-Click======*/
    /*jQuery('.dropdown-menu a.dropdown-toggle').on('click', function(e) {
      if (!jQuery(this).next().hasClass('show')) {
        jQuery(this).parents('.dropdown-menu').first().find('.show').removeClass("show");
      }
      var $subMenu = jQuery(this).next(".dropdown-menu");
      $subMenu.toggleClass('show');

      jQuery(this).parents('li.nav-item.dropdown.show').on('hidden.bs.dropdown', function(e) {
        jQuery('.dropdown-submenu .show').removeClass("show");
      });

      return false;
    });  */

    /*===Responsive-Mega=Menu===*/   
    jQuery('.mega-menu').meanmenu();    

    /*====Home-Banner-Slider======*/
    jQuery("#home_banner_slider").owlCarousel({ 
        items:1,
        loop:true,
        nav : true,
        dots: true,
        mouseDrag:true, 
        autoplay:true,
        autoplayTimeout:8000, 
        slideSpeed : 800,
        paginationSpeed : 600,
        responsive:{
            0:{
                nav: false
            },
            577:{
                nav: false
            },
            768:{
                nav: true
            },
            992:{
                nav: true
            }
        }                       
    });

    /*=====carousel-comn-style=======*/       
    jQuery('.carousel-comn-style .owl-carousel').owlCarousel({
        loop:true,
        margin:10,
        slideSpeed : 800,
        paginationSpeed : 400,
        mouseDrag:true,
        rewind:true,
        nav:true,
        dots: false,
        autoplay:true,
        autoplayTimeout:8000,           
        responsive:{
            0:{
                items:1
            },
            577:{
                items:2
            },
            768:{
                items:2
            },
            992:{
                items:4
            }
        }
    });
    
    /*=====testimonial_slider=======*/
    jQuery('#testimonial_slider').owlCarousel({
        items: 1,
        loop:true,
        margin:10,
        slideSpeed : 800,
        paginationSpeed : 400,
        mouseDrag:true,
        rewind:true,
        nav:true,
        dots: false,
        autoplay:true,
        autoplayTimeout:8000, 
        responsive:{
            0:{
                nav:false,
                dots: true,
            },
            991:{
                nav:false,
                dots: true,
            },
            992:{
                nav:true,
                dots: false,
            }            
        }          
       
    });

    /*============*/
    jQuery('.image_preview a').click(function(){
      var largeImage = jQuery(this).attr('data-full');
      jQuery('.selected').removeClass();
      jQuery(this).addClass('selected');
      jQuery('.full img').hide();
      jQuery('.full img').attr('src', ''+largeImage);
      jQuery('.full img').fadeIn();


    }); // closing the listening on a click
    jQuery('.full img').on('click', function(){
      var modalImage = jQuery(this).attr('src');
      $.fancybox.open(modalImage);
    });

   jQuery('.btn-number').click(function(e){
        e.preventDefault();
      
        fieldName = jQuery(this).attr('data-field');
        type      = jQuery(this).attr('data-type');
        var input = jQuery("input[name='"+fieldName+"']");
        var currentVal = parseInt(input.val());
        if (!isNaN(currentVal)) {
            if(type == 'minus') {
                
                if(currentVal > input.attr('min')) {
                    input.val(currentVal - 1).change();
                } 
                if(parseInt(input.val()) == input.attr('min')) {
                    jQuery(this).attr('disabled', true);
                }

            } else if(type == 'plus') {

                if(currentVal < input.attr('max')) {
                    input.val(currentVal + 1).change();
                }
                if(parseInt(input.val()) == input.attr('max')) {
                    jQuery(this).attr('disabled', true);
                }

            }
        } else {
            input.val(0);
        }
    });
    jQuery('.input-number').focusin(function(){
       jQuery(this).data('oldValue', jQuery(this).val());
    });
    jQuery('.input-number').change(function() {
        
        minValue =  parseInt(jQuery(this).attr('min'));
        maxValue =  parseInt(jQuery(this).attr('max'));
        valueCurrent = parseInt(jQuery(this).val());
        
        name = jQuery(this).attr('name');
        if(valueCurrent >= minValue) {
            jQuery(".btn-number[data-type='minus'][data-field='"+name+"']").removeAttr('disabled')
        } else {
            alert('Sorry, the minimum value was reached');
            jQuery(this).val(jQuery(this).data('oldValue'));
        }
        if(valueCurrent <= maxValue) {
            jQuery(".btn-number[data-type='plus'][data-field='"+name+"']").removeAttr('disabled')
        } else {
            alert('Sorry, the maximum value was reached');
            jQuery(this).val(jQuery(this).data('oldValue'));
        }
        
        
    });
    jQuery(".input-number").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 190]) !== -1 ||
             // Allow: Ctrl+A
            (e.keyCode == 65 && e.ctrlKey === true) || 
             // Allow: home, end, left, right
            (e.keyCode >= 35 && e.keyCode <= 39)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });

     /*====scroll body to 0px on click===*/
    jQuery(window).scroll(function () {
        if (jQuery(this).scrollTop() > 50) {
            jQuery('#back-to-top').fadeIn();
        } else {
            jQuery('#back-to-top').fadeOut();
        }
    });       
    jQuery('#back-to-top').click(function () {
        jQuery('#back-to-top').tooltip('hide');
        jQuery('body,html').animate({
            scrollTop: 0
        }, 800);
        return false;
    });        
    jQuery('#back-to-top').tooltip('show');    
});

